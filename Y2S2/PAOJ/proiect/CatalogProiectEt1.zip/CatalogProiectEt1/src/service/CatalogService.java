package service;

import model.*;
import java.util.*;
import java.util.stream.Collectors;

public class CatalogService {
    private List<Student> studenti = new ArrayList<>();
    private Set<Materie> materii = new TreeSet<>();

    public void adaugaStudent(Student student) {
        studenti.add(student);
    }

    public List<Student> getStudenti() {
        return new ArrayList<>(studenti);
    }

    public void actualizeazaStudent(int id, String nume, String prenume, String grupa) {
        for (Student student : studenti) {
            if (student.getId() == id) {
                student.setNume(nume);
                student.setPrenume(prenume);
                student.setGrupa(grupa);
                return;
            }
        }
        System.out.println("Studentul cu ID " + id + " nu a fost găsit.");
    }

    public void stergeStudent(int id) {
        studenti.removeIf(student -> student.getId() == id);
    }

    public List<Student> getStudentiByGrupa(String grupa) {
        return studenti.stream()
                .filter(student -> student.getGrupa().equalsIgnoreCase(grupa))
                .collect(Collectors.toList());
    }

    public void adaugaMaterie(Materie materie) {
        materii.add(materie);
    }

    public Set<Materie> getMaterii() {
        return new TreeSet<>(materii);
    }

    public void actualizeazaMaterie(int id, String denumire, int profesorId) {
        Materie materieExistenta = null;
        for (Materie m : materii) {
            if (m.getId() == id) {
                materieExistenta = m;
                break;
            }
        }
        if (materieExistenta != null) {
            materii.remove(materieExistenta);
            materieExistenta.setDenumire(denumire);
            materieExistenta.setProfesorId(profesorId);
            materii.add(materieExistenta);
        } else {
            System.out.println("Materia cu ID " + id + " nu a fost găsită.");
        }
    }



    public void stergeMaterie(int id) {
        materii.removeIf(materie -> materie.getId() == id);
    }

}