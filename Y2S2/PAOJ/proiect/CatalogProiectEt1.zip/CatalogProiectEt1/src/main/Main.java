package main;

import model.*;
import service.CatalogService;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        CatalogService service = new CatalogService();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\nMeniu Catalog Academic:");
            System.out.println("1. Adaugă student");
            System.out.println("2. Afișează studenți");
            System.out.println("3. Actualizează student");
            System.out.println("4. Șterge student");
            System.out.println("5. Afișează studenți după grupă");
            System.out.println("6. Adaugă materie");
            System.out.println("7. Afișează materii");
            System.out.println("8. Actualizează materie");
            System.out.println("9. Șterge materie");
            System.out.println("0. Ieșire");
            System.out.print("Alege o opțiune: ");

            int optiune;
            try {
                optiune = scanner.nextInt();
                scanner.nextLine();
            } catch (Exception e) {
                scanner.nextLine();
                System.out.println("Te rog introdu un număr valid.");
                continue;
            }

            switch (optiune) {
                case 1:
                    System.out.print("ID student: ");
                    int idStudent = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nume: ");
                    String nume = scanner.nextLine();
                    System.out.print("Prenume: ");
                    String prenume = scanner.nextLine();
                    System.out.print("Grupa: ");
                    String grupa = scanner.nextLine();
                    System.out.print("Este student master? (da/nu): ");
                    String esteMaster = scanner.nextLine().toLowerCase();
                    if (esteMaster.equals("da")) {
                        System.out.print("Tema master: ");
                        String temaMaster = scanner.nextLine();
                        service.adaugaStudent(new StudentMaster(idStudent, nume, prenume, grupa, temaMaster));
                    } else {
                        service.adaugaStudent(new Student(idStudent, nume, prenume, grupa));
                    }
                    System.out.println("Student adăugat cu succes.");
                    break;

                case 2:
                    System.out.println("Lista studenților:");
                    for (Student s : service.getStudenti()) {
                        System.out.println(s);
                    }
                    break;

                case 3:
                    System.out.print("ID student de actualizat: ");
                    int idUpdate = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nume nou: ");
                    String numeNou = scanner.nextLine();
                    System.out.print("Prenume nou: ");
                    String prenumeNou = scanner.nextLine();
                    System.out.print("Grupa nouă: ");
                    String grupaNoua = scanner.nextLine();
                    service.actualizeazaStudent(idUpdate, numeNou, prenumeNou, grupaNoua);
                    System.out.println("Student actualizat (dacă exista).");
                    break;

                case 4:
                    System.out.print("ID student de șters: ");
                    int idStergere = scanner.nextInt();
                    scanner.nextLine();
                    service.stergeStudent(idStergere);
                    System.out.println("Student șters (dacă exista).");
                    break;

                case 5:
                    System.out.print("Grupa: ");
                    String grupaCautata = scanner.nextLine();
                    System.out.println("Studenți în grupa " + grupaCautata + ":");
                    for (Student s : service.getStudentiByGrupa(grupaCautata)) {
                        System.out.println(s);
                    }
                    break;

                case 6:
                    System.out.print("ID materie: ");
                    int idMaterie = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Denumire materie: ");
                    String denumire = scanner.nextLine();
                    System.out.print("ID profesor (asociat): ");
                    int profesorId = scanner.nextInt();
                    scanner.nextLine();
                    service.adaugaMaterie(new Materie(idMaterie, denumire, profesorId));
                    System.out.println("Materie adăugată cu succes.");
                    break;

                case 7:
                    System.out.println("Lista materiilor:");
                    for (Materie m : service.getMaterii()) {
                        System.out.println(m);
                    }
                    break;

                case 8:
                    System.out.print("ID materie de actualizat: ");
                    int idUpdateMaterie = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Denumire nouă: ");
                    String denumireNoua = scanner.nextLine();
                    System.out.print("ID nou profesor: ");
                    int profesorNou = scanner.nextInt();
                    scanner.nextLine();
                    service.actualizeazaMaterie(idUpdateMaterie, denumireNoua, profesorNou);
                    System.out.println("Materie actualizată (dacă exista).");
                    break;

                case 9:
                    System.out.print("ID materie de șters: ");
                    int idStergereMaterie = scanner.nextInt();
                    scanner.nextLine();
                    service.stergeMaterie(idStergereMaterie);
                    System.out.println("Materie ștearsă (dacă exista).");
                    break;

                case 0:
                    running = false;
                    System.out.println("Programul s-a încheiat.");
                    break;

                default:
                    System.out.println("Opțiune invalidă. Te rog să alegi din nou.");
            }
        }
        scanner.close();
    }
}